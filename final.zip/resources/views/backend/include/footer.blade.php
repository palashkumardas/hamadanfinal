<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner" style="text-align: center;">
            
            <div class="app-footer-left">
                <ul class="nav">
                    <li class="nav-item">
                        <a href="javascript:void(0);" class="nav-link">
                            Footer Link 1
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="javascript:void(0);" class="nav-link">
                            Footer Link 2
                        </a>
                    </li>
                </ul>
            </div>
            <div class="app-footer-right">
                <b style="text-align: center;">Copyright © ShaPrime 2020</b>
            </div>
        </div>
    </div>
</div>