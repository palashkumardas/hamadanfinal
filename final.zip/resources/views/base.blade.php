
  {{-- header --}}
  @include('layouts.header_new')

  <!-- ======= Hero Section ======= -->
  @yield('content')
  <!-- End #main -->

  <!-- ======= Footer ======= -->

  @include('layouts.footer_new')
  <!-- End Footer -->