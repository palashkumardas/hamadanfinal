@extends('base')
@section('content')
@section('title','Home')
    @php $contact = App\Models\Contact::get()->first() @endphp
    @php $about = App\Models\About::get()->first() @endphp

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
      <h1>Welcome to <span>Hamadan</span></h1>
      <h2>The Fastest & Most Trusted Way to Send Money Worldwide</h2>
      <div class="d-flex">
        <a href="#about" class="btn-get-started scrollto">Get Started</a>
        <!--<a href="#" class="glightbox btn-watch-video"><i class="bi bi-play-circle"></i><span>Watch Video</span></a>-->
      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <h3 style="font-size: 42px;">Send Money with Hamadan <br>in <span>3 simple steps</span></h3>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
                    <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
                        <div class="icon"><img src="{{ asset('frontend_new/assets/img/icon/open An account-01.png')}}"></div>
                        <h4 class="title"><a href="">Open an Account</a></h4>
                        <p class="description">Opening a Hamadan account is fast, free and easy - just enter your
                            details, verify your identity and you’re all set</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
                    <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
                        <div class="icon"><img src="{{ asset('frontend_new/assets/img/icon/Transfer Money-01.png')}}"></div>
                        <h4 class="title"><a href="">Transfer Money</a></h4>
                        <p class="description">We are multiple secure options to send money back home: bank transfer,
                            mobile wallet, bank deposit, instant, low-cost,
                            whatever works best for you</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
                    <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
                        <div class="icon"><img src="{{ asset('frontend_new/assets/img/icon/Time To Wait-01.png')}}"></div>
                        <h4 class="title"><a href="">Time to wait</a></h4>
                        <p class="description">That’s it! Most fund arrive instantly, with notifications keeping you
                            updated for total peace of mind</p>
                    </div>
                </div>

            </div>

        </div>
    </section>
    <!-- End Featured Services Section -->


    <!-- ======= About Section ======= -->
    <section id="about" class="about section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About</h2>
          <h3>Find Out More <span>About Us</span></h3>
        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-right" data-aos-delay="100">
            <img src="{{ asset('frontend_new/assets/img/about.jpg')}}" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="100">
            <p class="fst-italic">{!! $about->description !!}</p>
          </div>
        </div>

      </div>
    </section>
    <!-- End About Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <h3>Why choose Hamadan <span>Services?</span></h3>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="mb-4"><img src="{{ asset('frontend_new/assets/img/icon/Send Money-01.png')}}"></div>
              <h4><a href="">Send Money</a></h4>
              <p>With so many options to choose from, it's quick and easy to send money. Many transfers come
                within a few minutes.</p>
            </div>
          </div>
    
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="mb-4"><img src="{{ asset('frontend_new/assets/img/icon/Reliable and Safety-01.png')}}"></div>
              <h4><a href="">Reliable & Safety</a></h4>
              <p>Hamadan Online allows you to send your information and money with confidence. We make sure
                your money be safe 100%
                guarantee</p>
            </div>
          </div>
    
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="mb-4"><img src="{{ asset('frontend_new/assets/img/icon/Converstions-01.png')}}"></div>
              <h4><a href="">Conversions</a></h4>
              <p>Convert to any currencies anytime and save more with our highly competitive exchange
                rates</p>
            </div>
          </div>
    
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="mb-4"><img src="{{ asset('frontend_new/assets/img/icon/Convinient-01.png')}}"></div>
              <h4><a href="">Convenient</a></h4>
              <p>Our global network includes well-known retailers and businesses in over 100 countries and
                territories, making it easy to
                collect cash for your recipient.</p>
            </div>
          </div>
    
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="mb-4"><img src="{{ asset('frontend_new/assets/img/icon/Real Time Rate-01.png')}}"></div>
              <h4><a href="">Real Time Rate</a></h4>
              <p>We provide you the real time exchange rate for over 100+ currencies</p>
            </div>
          </div>
    
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="mb-4"><img src="{{ asset('frontend_new/assets/img/icon/low cost-01.png')}}"></div>
              <h4><a href="">Low Cost</a></h4>
              <p>See our low fees and our best exchange rates up front, with no hidden costs</p>
            </div>
          </div>
    
        </div>

      </div>
    </section>
    <!-- End Services Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact pt-0">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <h3><span>Contact Us</span></h3>
          <!--<p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>-->
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
              <p>{{ $contact->address }}</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <p>{{ $contact->email_one }}</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <p>{{ $contact->phone_one }}</p>
            </div>
          </div>

        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-6 ">
            <iframe class="mb-4 mb-lg-0"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.6642414067096!2d-0.05953278407462822!3d51.51937561764833!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761cd21644186d%3A0xe3c51def34e38bde!2sUnit%205%2C%20214%20Whitechapel%20Rd%2C%20London%20E1%201BJ%2C%20UK!5e0!3m2!1sen!2sbd!4v1658987767301!5m2!1sen!2sbd "
                            frameborder="0" style="border:0; width: 100%; height: 384px;" allowfullscreen></iframe>
          </div>

          <div class="col-lg-6">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

@endsection