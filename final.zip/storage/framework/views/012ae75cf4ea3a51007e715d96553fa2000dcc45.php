
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Terms & Conditions'); ?>
    <?php $contact = App\Models\Contact::get()->first() ?>
    <?php $about = App\Models\About::get()->first() ?>
    <?php $terms = App\Models\TermsConditions::get()->first() ?>
     


  <main id="main" data-aos="fade-up">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Terms & Conditions</h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li>Terms & Conditions</li>
          </ol>
        </div>

      </div>
    </section>
    <!-- End Breadcrumbs -->
    <!-- ======= About Section ======= -->
    <section id="about" class="about ">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>terms & conditions</h2>
           <h3>Terms & Conditions</h3>
        </div>

        <div class="row">
          <div class="col-md-12">
            <div>
              <!-- Privacy policy Details -->
             <p><?php echo $terms->description; ?></p>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

  </main><!-- End #main -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamadanint/public_html/resources/views/pages/terms.blade.php ENDPATH**/ ?>