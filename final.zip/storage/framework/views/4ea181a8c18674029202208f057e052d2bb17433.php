
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Terms & Conditions'); ?>
  <main id="main" style="margin-top: 80px;">

   <div class="container">
      <h1><center> Terms & Conditions</center></h1>
      
      <p><?php echo $terms->description; ?></p>

   </div>

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Radwan\Razeken\razikeen\resources\views/layouts/terms_condition.blade.php ENDPATH**/ ?>