
<?php $__env->startSection('title', $title); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets/node_modules/summernote/dist/summernote-bs4.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <form method="POST" action="<?php echo e(route('admin.contact.update')); ?>">
            <?php echo csrf_field(); ?>
            
            <div class="card">
                <div class="card-header">
                    <button type="submit" class="btn btn-primary" style="float: right;">Update</button>
                    <?php echo e($title); ?> Update
                </div>
                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                <div class="card-body table-responsive">
                    <div class="form-row mb-3">
                        <div class="col">
                            <label for="title">Title</label>
                            <input type="text" class="form-control" id="title" name="title" placeholder="Title" value="<?php echo e($data->title); ?>">
                        </div>
                        <div class="col">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" id="address" name="address" placeholder="Address" value="<?php echo e($data->address); ?>">
                        </div>
                        <div class="col">
                            <label for="office_hours">Office Hours</label>
                            <input type="text" class="form-control" id="office_hours" name="office_hours" placeholder="Office Hours" value="<?php echo e($data->office_hours); ?>">
                        </div>
                    </div>
                    <div class="form-row mb-3">
                        <div class="col">
                            <label for="phone_one">Phone One</label>
                            <input type="text" class="form-control" id="phone_one" name="phone_one" placeholder="Phone One" value="<?php echo e($data->phone_one); ?>">
                        </div>
                        <div class="col">
                            <label for="phone_two">Phone Two</label>
                            <input type="text" class="form-control" id="phone_two" name="phone_two" placeholder="Phone Two" value="<?php echo e($data->phone_two); ?>">
                        </div>
                        <div class="col">
                            <label for="phone_three">Phone Three</label>
                            <input type="text" class="form-control" id="phone_three" name="phone_three" placeholder="Phone Three" value="<?php echo e($data->phone_three); ?>">
                        </div>
                    </div>
                    <div class="form-row mb-3">
                        <div class="col">
                            <label for="email_one">Email One</label>
                            <input type="text" class="form-control" id="email_one" name="email_one" placeholder="Email One" value="<?php echo e($data->email_one); ?>">
                        </div>
                        <div class="col">
                            <label for="email_two">Email Two</label>
                            <input type="text" class="form-control" id="email_two" name="email_two" placeholder="Email Two" value="<?php echo e($data->email_two); ?>">
                        </div>
                        <div class="col">
                            <label for="email_three">Email Three</label>
                            <input type="text" class="form-control" id="email_three" name="email_three" placeholder="Email Three" value="<?php echo e($data->email_three); ?>">
                        </div>
                    </div>
                    <div class="form-row mb-3">
                        <div class="col">
                            <label for="facebook">Facebook</label>
                            <input type="text" class="form-control" id="facebook" name="facebook" placeholder="www.facebook.com/" value="<?php echo e($data->facebook); ?>">
                        </div>
                        <div class="col">
                            <label for="twitter">Twitter</label>
                            <input type="text" class="form-control" id="twitter" name="twitter" placeholder="www.twitter.com/" value="<?php echo e($data->twitter); ?>">
                        </div>
                        <div class="col">
                            <label for="linkedin">Linkedin</label>
                            <input type="text" class="form-control" id="linkedin" name="linkedin" placeholder="www.linkedin.com/" value="<?php echo e($data->linkedin); ?>">
                        </div>
                    </div>
                    <div class="form-row mb-3">
                        <div class="col">
                            <label for="youtube">Youtube</label>
                            <input type="text" class="form-control" id="youtube" name="youtube" placeholder="www.youtube.com/" value="<?php echo e($data->youtube); ?>">
                        </div>
                        <div class="col">
                            <label for="instagram">Instagram</label>
                            <input type="text" class="form-control" id="instagram" name="instagram" placeholder="www.instagram.com/" value="<?php echo e($data->instagram); ?>">
                        </div>
                        <div class="col">
                            <!-- <label for="map_location">Map Location</label>
                            <input type="text" class="form-control" id="map_location" name="map_location" placeholder="www.google.com/" value="<?php echo e($data->map_location); ?>"> -->
                        </div>
                    </div>
                    <div class="form-row mb-3">
                        <label for="description">Description</label>
                        <input type="text" class="form-control" id="description" name="description" placeholder="sort description" value="<?php echo e($data->description); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\razekaan\resources\views/backend/pages/contact_us.blade.php ENDPATH**/ ?>