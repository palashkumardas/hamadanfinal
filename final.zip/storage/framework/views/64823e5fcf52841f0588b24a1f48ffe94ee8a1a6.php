<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- User Profile-->
        <div class="user-profile">
            <div class="user-pro-body">
                <div>
                    <img src="<?php echo e(asset('backend/assets/images/razekeen.png')); ?>" alt="user-img" class="img-circle">
                </div>
                <div class="dropdown">
                    <a href="javascript:void(0)" class="dropdown-toggle u-dropdown link hide-menu" data-toggle="dropdown" role="button" aria-haspopup="true"
                        
                        <span class="caret"></span>
                    </a>
                    <div class="dropdown-menu animated flipInY">
                        <!-- text-->
                        <a href="javascript:void(0)" class="dropdown-item">
                            <i class="ti-user"></i> My Profile</a>
                        <!-- text-->
                        <!-- text-->
                        <div class="dropdown-divider"></div>
                        <!-- text-->
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <i class="fa fa-power-off"></i> Logout</a>
                        
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                            
                        <!-- text-->
                    </div>
                </div>
            </div>
        </div>
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li>
                    <a class="waves-effect waves-dark" href="<?php echo e(url('admin/dashboard')); ?>" aria-expanded="false">
                        <i class="icon-speedometer"></i> 
                        <span class="hide-menu">Dashboard</span>
                    </a>
                </li>

                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-bar-chart-alt"></i><span class="hide-menu">Settings</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="<?php echo e(route('admin.about')); ?>">About Us</a></li>
                        <li><a href="<?php echo e(route('admin.contact')); ?>">Contact Us</a></li>
                        <li><a href="<?php echo e(route('admin.policy')); ?>">Privacy & Policy</a></li>
                        <li><a href="<?php echo e(route('admin.terms')); ?>">Terms & Condition</a></li>
                        <li><a href="<?php echo e(route('admin.cookies')); ?>">Cookies Policy</a></li>
                       
                    </ul>
                </li>
               
                <li>
                    <a class="waves-effect waves-dark" href="#" aria-expanded="false">
                        <i class="icon-speedometer"></i> 
                        <span class="hide-menu">Site Settings</span>
                    </a>
                </li>
            

                <!-- <li>
                    <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                        <i class="ti-user"></i>
                        <span class="hide-menu">User</span>
                    </a>
                    <ul aria-expanded="false" class="collapse">
                        <li>
                            <a href="<?php echo e(url('users')); ?>">User List</a>
                        </li>
                    </ul>
                </li> -->
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside><?php /**PATH E:\razekaan2\resources\views/backend/include/sidebar.blade.php ENDPATH**/ ?>