
  
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- ======= Hero Section ======= -->
  <?php echo $__env->yieldContent('content'); ?>
  <!-- End #main -->

  <!-- ======= Footer ======= -->

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Footer --><?php /**PATH D:\Devsstream\2022\razikeen\razikeen\resources\views/master.blade.php ENDPATH**/ ?>