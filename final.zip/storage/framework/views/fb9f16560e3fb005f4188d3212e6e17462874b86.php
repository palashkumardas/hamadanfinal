
  
  <?php echo $__env->make('layouts.header_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- ======= Hero Section ======= -->
  <?php echo $__env->yieldContent('content'); ?>
  <!-- End #main -->

  <!-- ======= Footer ======= -->

  <?php echo $__env->make('layouts.footer_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Footer --><?php /**PATH /home/u17shag/public_html/hamadan/resources/views/base.blade.php ENDPATH**/ ?>